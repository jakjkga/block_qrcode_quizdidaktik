# QR-Code Quizdidaktik
## block_qrcode_quizdidaktik

Moodle Block Plugin für die Anzeige eines QR-Codes, der mit JavaScript erzeugt wird

Basiert auf der JavaScript Bibliothek "QRQode for Javascript" (MIT-Lizenz) von
  * [Kazuhiko Arase, 2009](http://www.d-project.com/)
  * [Sangmin Shim, 2012](https://github.com/davidshimjs/qrcodejs)
  
sowie dem online QR-Code Generator von

  * [Joachim Jakob, 2017](https://quizdidaktik.de/qrcodegenerator-2.0/)

![Screenshot](QR-Code_Quizdidaktik_Screenshot.png)
