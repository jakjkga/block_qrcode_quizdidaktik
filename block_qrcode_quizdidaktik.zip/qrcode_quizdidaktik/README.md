# QR-Code Quizdidaktik

## Kurzbezeichnung

`block_qrcode_quizdidaktik`

## What it does

Add a QR-Code in a Moodle Block, generated with JavaScript.

## Licence

It's using the Javascript Library "QRCode for Javscript" under MIT-Licence by
  * [Kazuhiko Arase, 2009](http://www.d-project.com/)
  * [Sangmin Shim, 2012](https://github.com/davidshimjs/qrcodejs)
  * [Joachim Jakob, 2017](https://quizdidaktik.de/qrcodegenerator-2.0/)



